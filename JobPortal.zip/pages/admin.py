# from django.contrib import admin
#
# from pages.models import RecruiterPosting
#
# admin.site.register(RecruiterPosting)
